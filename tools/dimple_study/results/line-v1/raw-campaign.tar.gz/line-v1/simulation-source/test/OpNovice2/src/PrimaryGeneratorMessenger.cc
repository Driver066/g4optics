//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
/// \file optical/OpNovice2/src/PrimaryGeneratorMessenger.cc
/// \brief Implementation of the PrimaryGeneratorMessenger class
//
//
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#include "PrimaryGeneratorMessenger.hh"

#include "PrimaryGeneratorAction.hh"

#include "G4SystemOfUnits.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIdirectory.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PrimaryGeneratorMessenger::PrimaryGeneratorMessenger(PrimaryGeneratorAction* Gun)
  : G4UImessenger(), fPrimaryAction(Gun)
{
  fGunDir = new G4UIdirectory("/opnovice2/gun/");
  fGunDir->SetGuidance("PrimaryGenerator control");

  fPolarCmd = new G4UIcmdWithADoubleAndUnit("/opnovice2/gun/optPhotonPolar", this);
  fPolarCmd->SetGuidance("Set linear polarization angle w.r.t. (k,n) plane");
  fPolarCmd->SetParameterName("angle", true);
  fPolarCmd->SetUnitCategory("Angle");
  fPolarCmd->SetDefaultValue(-360.0);
  fPolarCmd->SetDefaultUnit("deg");
  fPolarCmd->AvailableForStates(G4State_Idle);

  fRandomDirectionCmd = new G4UIcmdWithABool("/opnovice2/gun/randomDirection", this);
  fRandomDirectionCmd->SetGuidance("Set direction of each primary particle randomly.");
  fRandomDirectionCmd->SetDefaultValue(true);
  fRandomDirectionCmd->AvailableForStates(G4State_Idle, G4State_PreInit);

  fElectronEnergyModeCmd = new G4UIcmdWithAString("/opnovice2/gun/electronEnergyMode", this);
  fElectronEnergyModeCmd->SetGuidance("Set electron kinetic energy mode: fixed or sr90Beta.");
  fElectronEnergyModeCmd->SetGuidance("sr90Beta is the legacy empirical Sr-90/Y-90 proxy.");
  fElectronEnergyModeCmd->AvailableForStates(G4State_Idle, G4State_PreInit);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PrimaryGeneratorMessenger::~PrimaryGeneratorMessenger()
{
  delete fPolarCmd;
  delete fGunDir;
  delete fRandomDirectionCmd;
  delete fElectronEnergyModeCmd;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PrimaryGeneratorMessenger::SetNewValue(G4UIcommand* command, G4String newValue)
{
  if (command == fPolarCmd) {
    G4double angle = fPolarCmd->GetNewDoubleValue(newValue);
    if (angle == -360.0 * deg) {
      fPrimaryAction->SetOptPhotonPolar();
    }
    else {
      fPrimaryAction->SetOptPhotonPolar(angle);
    }
  }
  else if (command == fRandomDirectionCmd) {
    fPrimaryAction->SetRandomDirection(true);
  }
  else if (command == fElectronEnergyModeCmd) {
    fPrimaryAction->SetElectronEnergyMode(newValue);
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
