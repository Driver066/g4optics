//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
/// \file optical/OpNovice2/include/DetectorMessenger.hh
/// \brief Definition of the DetectorMessenger class
//
//
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#ifndef DetectorMessenger_h
#define DetectorMessenger_h 1

#include "G4UImessenger.hh"
#include "globals.hh"

class DetectorConstruction;
class G4UIdirectory;
class G4UIcommand;
class G4UIcmdWithAString;
class G4UIcmdWithABool;
class G4UIcmdWithAnInteger;
class G4UIcmdWithADouble;
class G4UIcmdWithADoubleAndUnit;
class G4UIcmdWithoutParameter;
class G4UIcmdWith3VectorAndUnit;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class DetectorMessenger : public G4UImessenger
{
  public:
    DetectorMessenger(DetectorConstruction*);
    ~DetectorMessenger() override;

    void SetNewValue(G4UIcommand*, G4String) override;

  private:
    DetectorConstruction* fDetector = nullptr;
    G4UIdirectory* fOpticalDir = nullptr;

    // the surface
    G4UIcmdWithAString* fSurfaceTypeCmd = nullptr;
    G4UIcmdWithAString* fSurfaceFinishCmd = nullptr;
    G4UIcmdWithAString* fSurfaceModelCmd = nullptr;
    G4UIcmdWithAString* fSurfacePresetCmd = nullptr;
    G4UIcmdWithADouble* fSurfaceSigmaAlphaCmd = nullptr;
    G4UIcmdWithADouble* fSurfacePolishCmd = nullptr;
    G4UIcmdWithAString* fSurfaceMatPropVectorCmd = nullptr;
    G4UIcmdWithAString* fSurfaceMatPropConstCmd = nullptr;

    // the box
    G4UIcmdWithAString* fTankMatPropVectorCmd = nullptr;
    G4UIcmdWithAString* fTankMatPropConstCmd = nullptr;
    G4UIcmdWithAString* fTankMaterialCmd = nullptr;
    G4UIcmdWith3VectorAndUnit* fTankSizeCmd = nullptr;
    G4UIcmdWithAString* fTankSizePresetCmd = nullptr;
    G4UIcmdWithABool* fTankBottomCavityCmd = nullptr;
    G4UIcmdWithABool* fAbsorberEnabledCmd = nullptr;
    G4UIcmdWith3VectorAndUnit* fAbsorberSizeCmd = nullptr;
    G4UIcmdWithABool* fStackEnabledCmd = nullptr;
    G4UIcmdWithABool* fStackLayoutStudyCmd = nullptr;
    G4UIcmdWithAnInteger* fStackLayersCmd = nullptr;
    G4UIcmdWithABool* fDimpleEnabledCmd = nullptr;
    G4UIcmdWithABool* fDimpleOpticalDiagnosticsCmd = nullptr;
    G4UIcmdWithABool* fSaveRandomStateCmd = nullptr;
    G4UIcmdWithADoubleAndUnit* fDimpleRadiusCmd = nullptr;
    G4UIcmdWithAString* fDimpleModeCmd = nullptr;
    G4UIcmdWithAString* fDimpleSiPMModeCmd = nullptr;

    // the world
    G4UIcmdWithAString* fWorldMatPropVectorCmd = nullptr;
    G4UIcmdWithAString* fWorldMatPropConstCmd = nullptr;
    G4UIcmdWithAString* fWorldMaterialCmd = nullptr;

    // SiPM geometry
    G4UIcmdWithAString* fSiPMLayoutCmd = nullptr;
    G4UIcmdWithAString* fSiPMFaceCmd = nullptr;
    G4UIcmdWithAString* fSiPMCavityModeCmd = nullptr;
    G4UIcmdWith3VectorAndUnit* fSiPMLocalPositionCmd = nullptr;
    G4UIcmdWith3VectorAndUnit* fSiPMSizeCmd = nullptr;

    // EJ-550 optical grease coupling
    G4UIcmdWithABool* fGreaseEnabledCmd = nullptr;
    G4UIcmdWithADoubleAndUnit* fGreaseThicknessCmd = nullptr;
    G4UIcmdWith3VectorAndUnit* fGreaseSizeCmd = nullptr;
    G4UIcmdWithAString* fGreaseMatPropVectorCmd = nullptr;
    G4UIcmdWithAString* fGreaseMatPropConstCmd = nullptr;
};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#endif
