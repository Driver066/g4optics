//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
/// \file optical/OpNovice2/src/RunAction.cc
/// \brief Implementation of the RunAction class
//
//
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#include "RunAction.hh"

#include "DetectorConstruction.hh"
#include "DimpleOpticalDiagnostics.hh"
#include "HistoManager.hh"
#include "PrimaryGeneratorAction.hh"
#include "Run.hh"

#include "G4Run.hh"
#include "G4RunManager.hh"
#include "G4Exception.hh"
#include "G4SystemOfUnits.hh"
#include "G4Threading.hh"
#include "G4UnitsTable.hh"
#include "Randomize.hh"

#include <fstream>
#include <iomanip>
#include <limits>

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
namespace
{
  void WriteScanSummary(const Run* run, const G4String& outputBaseName)
  {
    G4String summaryBaseName = outputBaseName;
    const auto rootExtension = summaryBaseName.rfind(".root");
    if (rootExtension != G4String::npos
        && rootExtension == summaryBaseName.size() - G4String(".root").size())
    {
      summaryBaseName.erase(rootExtension);
    }
    const G4String summaryFileName = summaryBaseName + "_summary.csv";
    std::ofstream out(summaryFileName);
    if (!out) {
      G4cerr << "Could not write scan summary CSV: " << summaryFileName << G4endl;
      return;
    }

    const auto generatedOptical = run->GetGeneratedOpticalCount();
    const auto sipmDetected = run->GetSiPMDetectionCount();
    const auto committedEvents = run->GetCommittedEventCount();
    const auto collectionEfficiencyValid = generatedOptical > 0;
    const auto collectionEfficiency =
      collectionEfficiencyValid
        ? G4double(sipmDetected) / G4double(generatedOptical)
        : std::numeric_limits<G4double>::quiet_NaN();
    const auto production = committedEvents > 0
      ? G4double(run->GetScintillationCount()) / G4double(committedEvents)
      : std::numeric_limits<G4double>::quiet_NaN();
    const auto netResponse = committedEvents > 0
      ? G4double(sipmDetected) / G4double(committedEvents)
      : std::numeric_limits<G4double>::quiet_NaN();
    const auto zeroFraction = [committedEvents](G4long nonzeroEvents) {
      return committedEvents > 0
        ? G4double(committedEvents - nonzeroEvents) / G4double(committedEvents)
        : std::numeric_limits<G4double>::quiet_NaN();
    };
    const auto missingPosition = std::numeric_limits<G4double>::quiet_NaN();
    const auto shootPosition = run->GetMeanShootPosition();
    const auto hitPosition = run->GetMeanHitPosition();
    const auto scintCentroid = run->GetMeanScintillationCentroid();
    const auto primaryEnergyCount = run->GetPrimaryKineticEnergyCount();
    const auto decayBetaCount = run->GetDecayBetaCount();

    out << "events,generated_optical_photons,scintillation_photons,"
        << "sipm_detected_photons,collection_efficiency,"
        << "shoot_position_events,shoot_x_mm,shoot_y_mm,shoot_z_mm,"
        << "hit_position_events,hit_x_mm,hit_y_mm,hit_z_mm,"
        << "scint_centroid_events,scint_centroid_x_mm,scint_centroid_y_mm,"
        << "scint_centroid_z_mm,"
        << "primary_energy_events,primary_energy_mean_mev,primary_energy_rms_mev,"
        << "primary_energy_min_mev,primary_energy_max_mev,"
        << "decay_beta_count,decay_beta_energy_mean_mev,decay_beta_energy_rms_mev,"
        << "decay_beta_energy_min_mev,decay_beta_energy_max_mev,"
        << "committed_events,collection_efficiency_valid,"
        << "production_scint_photons_per_event,net_sipm_photons_per_event,"
        << "cerenkov_photons,steel_edep_sum_mev,steel_edep_mean_mev,"
        << "steel_edep_rms_mev,steel_edep_se_mev,steel_edep_nonzero_events,"
        << "primary_neutron_interaction_events,primary_neutron_elastic_count,"
        << "primary_neutron_inelastic_count,primary_neutron_capture_count,"
        << "primary_neutron_elastic_events,primary_neutron_inelastic_events,"
        << "primary_neutron_capture_events,charged_tile_entry_events,"
        << "charged_tile_entry_count,charged_tile_entry_ke_sum_mev,"
        << "electron_tile_entry_count,electron_tile_entry_ke_sum_mev,"
        << "proton_tile_entry_count,proton_tile_entry_ke_sum_mev,"
        << "other_charged_tile_entry_count,other_charged_tile_entry_ke_sum_mev,"
        << "primary_neutron_tile_entry_events,tile_edep_sum_mev,"
        << "electron_tile_edep_sum_mev,proton_tile_edep_sum_mev,"
        << "other_charged_tile_edep_sum_mev,neutral_tile_edep_sum_mev,"
        << "tile_edep_mean_mev,tile_edep_rms_mev,tile_edep_se_mev,"
        << "tile_edep_nonzero_events,generated_optical_mean,generated_optical_rms,"
        << "generated_optical_se,generated_optical_zero_events,"
        << "generated_optical_zero_fraction,"
        << "scintillation_mean,scintillation_rms,scintillation_se,"
        << "scintillation_zero_events,scintillation_zero_fraction,"
        << "sipm_detected_mean,sipm_detected_rms,sipm_detected_se,"
        << "sipm_detected_zero_events,sipm_detected_zero_fraction\n";
    out << std::setprecision(17);
    out << run->GetNumberOfEvents() << ','
        << generatedOptical << ','
        << run->GetScintillationCount() << ','
        << sipmDetected << ','
        << collectionEfficiency << ','
        << run->GetShootPositionCount() << ','
        << (run->GetShootPositionCount() > 0 ? shootPosition.x() / mm : missingPosition) << ','
        << (run->GetShootPositionCount() > 0 ? shootPosition.y() / mm : missingPosition) << ','
        << (run->GetShootPositionCount() > 0 ? shootPosition.z() / mm : missingPosition) << ','
        << run->GetHitPositionCount() << ','
        << (run->GetHitPositionCount() > 0 ? hitPosition.x() / mm : missingPosition) << ','
        << (run->GetHitPositionCount() > 0 ? hitPosition.y() / mm : missingPosition) << ','
        << (run->GetHitPositionCount() > 0 ? hitPosition.z() / mm : missingPosition) << ','
        << run->GetScintillationCentroidCount() << ','
        << (run->GetScintillationCentroidCount() > 0 ? scintCentroid.x() / mm : missingPosition)
        << ','
        << (run->GetScintillationCentroidCount() > 0 ? scintCentroid.y() / mm : missingPosition)
        << ','
        << (run->GetScintillationCentroidCount() > 0 ? scintCentroid.z() / mm : missingPosition)
        << ','
        << primaryEnergyCount << ','
        << (primaryEnergyCount > 0 ? run->GetPrimaryKineticEnergyMean() / MeV : missingPosition)
        << ','
        << (primaryEnergyCount > 0 ? run->GetPrimaryKineticEnergyRms() / MeV : missingPosition)
        << ','
        << (primaryEnergyCount > 0 ? run->GetPrimaryKineticEnergyMin() / MeV : missingPosition)
        << ','
        << (primaryEnergyCount > 0 ? run->GetPrimaryKineticEnergyMax() / MeV : missingPosition)
        << ','
        << decayBetaCount << ','
        << (decayBetaCount > 0 ? run->GetDecayBetaEnergyMean() / MeV : missingPosition)
        << ','
        << (decayBetaCount > 0 ? run->GetDecayBetaEnergyRms() / MeV : missingPosition)
        << ','
        << (decayBetaCount > 0 ? run->GetDecayBetaEnergyMin() / MeV : missingPosition)
        << ','
        << (decayBetaCount > 0 ? run->GetDecayBetaEnergyMax() / MeV : missingPosition)
        << ','
        << committedEvents << ','
        << (collectionEfficiencyValid ? 1 : 0) << ','
        << production << ','
        << netResponse << ','
        << run->GetCerenkovCount() << ','
        << run->GetSteelEnergyDepositSum() / MeV << ','
        << run->GetSteelEnergyDepositMean() / MeV << ','
        << run->GetSteelEnergyDepositRms() / MeV << ','
        << run->GetSteelEnergyDepositStandardError() / MeV << ','
        << run->GetSteelEnergyDepositNonzeroEventCount() << ','
        << run->GetPrimaryNeutronInteractionEventCount() << ','
        << run->GetPrimaryNeutronElasticInteractionCount() << ','
        << run->GetPrimaryNeutronInelasticInteractionCount() << ','
        << run->GetPrimaryNeutronCaptureInteractionCount() << ','
        << run->GetPrimaryNeutronElasticEventCount() << ','
        << run->GetPrimaryNeutronInelasticEventCount() << ','
        << run->GetPrimaryNeutronCaptureEventCount() << ','
        << run->GetChargedTileEntryEventCount() << ','
        << run->GetChargedTileEntryCount() << ','
        << run->GetChargedTileEntryKineticEnergySum() / MeV << ','
        << run->GetElectronTileEntryCount() << ','
        << run->GetElectronTileEntryKineticEnergySum() / MeV << ','
        << run->GetProtonTileEntryCount() << ','
        << run->GetProtonTileEntryKineticEnergySum() / MeV << ','
        << run->GetOtherChargedTileEntryCount() << ','
        << run->GetOtherChargedTileEntryKineticEnergySum() / MeV << ','
        << run->GetPrimaryNeutronTileEntryEventCount() << ','
        << run->GetTileEnergyDepositSum() / MeV << ','
        << run->GetElectronTileEnergyDepositSum() / MeV << ','
        << run->GetProtonTileEnergyDepositSum() / MeV << ','
        << run->GetOtherChargedTileEnergyDepositSum() / MeV << ','
        << run->GetNeutralTileEnergyDepositSum() / MeV << ','
        << run->GetTileEnergyDepositMean() / MeV << ','
        << run->GetTileEnergyDepositRms() / MeV << ','
        << run->GetTileEnergyDepositStandardError() / MeV << ','
        << run->GetTileEnergyDepositNonzeroEventCount() << ','
        << run->GetGeneratedOpticalMean() << ','
        << run->GetGeneratedOpticalRms() << ','
        << run->GetGeneratedOpticalStandardError() << ','
        << committedEvents - run->GetGeneratedOpticalNonzeroEventCount() << ','
        << zeroFraction(run->GetGeneratedOpticalNonzeroEventCount()) << ','
        << run->GetScintillationMean() << ','
        << run->GetScintillationRms() << ','
        << run->GetScintillationStandardError() << ','
        << committedEvents - run->GetScintillationNonzeroEventCount() << ','
        << zeroFraction(run->GetScintillationNonzeroEventCount()) << ','
        << run->GetSiPMDetectionMean() << ','
        << run->GetSiPMDetectionRms() << ','
        << run->GetSiPMDetectionStandardError() << ','
        << committedEvents - run->GetSiPMDetectionNonzeroEventCount() << ','
        << zeroFraction(run->GetSiPMDetectionNonzeroEventCount())
        << '\n';
  }
}

RunAction::RunAction(PrimaryGeneratorAction* prim)
  : G4UserRunAction(), fRun(nullptr), fHistoManager(nullptr), fPrimary(prim)
{
  fHistoManager = new HistoManager();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

RunAction::~RunAction()
{
  delete fHistoManager;
}

G4Run* RunAction::GenerateRun()
{
  fRun = new Run();
  return fRun;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void RunAction::BeginOfRunAction(const G4Run*)
{
  if (fPrimary) {
    G4ParticleDefinition* particle = fPrimary->GetGeneralParticleSource()->GetParticleDefinition();
    G4double energy = fPrimary->GetGeneralParticleSource()->GetParticleEnergy();
    G4bool polarized = fPrimary->GetPolarized();
    G4double polarization = fPrimary->GetPolarization();
    fRun->SetPrimary(particle, energy, polarized, polarization, fPrimary->GetElectronEnergyMode());
  }

  // histograms
  const auto* detector = static_cast<const DetectorConstruction*>(
    G4RunManager::GetRunManager()->GetUserDetectorConstruction());
  if (detector && detector->IsRandomStateSavingEnabled() &&
      G4Threading::IsMultithreadedApplication()) {
    G4Exception("RunAction::BeginOfRunAction", "DimpleRandom_001", FatalException,
                "The optional RNG end-state file requires a Serial run manager.");
  }
  DimpleOpticalDiagnostics::BeginRun(detector);
  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();
  if (analysisManager->IsActive()) {
    analysisManager->OpenFile();
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void RunAction::EndOfRunAction(const G4Run*)
{
  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();

  if (isMaster) {
    fRun->EndOfRun();
    WriteScanSummary(fRun, analysisManager->GetFileName());
  }

  G4cout << G4endl << " Histogram statistics for the ";
  if (isMaster) {
    G4cout << "entire run:" << G4endl << G4endl;
  }
  else {
    G4cout << "local thread:" << G4endl << G4endl;
  }

  G4int id = analysisManager->GetH1Id("Cerenkov spectrum");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Cerenkov spectrum: mean = " << analysisManager->GetH1(id)->mean()
           << " eV; rms = " << analysisManager->GetH1(id)->rms() << " eV." << G4endl;
  }
  id = analysisManager->GetH1Id("Scintillation spectrum");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Scintillation spectrum: mean = " << analysisManager->GetH1(id)->mean()
           << " eV; rms = " << analysisManager->GetH1(id)->rms() << " eV." << G4endl;
  }
  id = analysisManager->GetH1Id("Scintillation time");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Scintillation time: mean = " << analysisManager->GetH1(id)->mean()
           << " ns; rms = " << analysisManager->GetH1(id)->rms() << " ns." << G4endl;
  }
  id = analysisManager->GetH1Id("WLS abs");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " WLS absorption spectrum: mean = " << analysisManager->GetH1(id)->mean()
           << " eV; rms = " << analysisManager->GetH1(id)->rms() << " eV." << G4endl;
  }
  id = analysisManager->GetH1Id("WLS em");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " WLS emission spectrum: mean = " << analysisManager->GetH1(id)->mean()
           << " eV; rms = " << analysisManager->GetH1(id)->rms() << " eV." << G4endl;
  }
  id = analysisManager->GetH1Id("WLS time");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " WLS emission time: mean = " << analysisManager->GetH1(id)->mean()
           << " ns; rms = " << analysisManager->GetH1(id)->rms() << " ns." << G4endl;
  }
  id = analysisManager->GetH1Id("WLS2 abs");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " WLS emission time: mean = " << analysisManager->GetH1(id)->mean()
           << " ns; rms = " << analysisManager->GetH1(id)->rms() << " ns." << G4endl;
  }
  id = analysisManager->GetH1Id("WLS2 em");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " WLS2 emission spectrum: mean = " << analysisManager->GetH1(id)->mean()
           << " eV; rms = " << analysisManager->GetH1(id)->rms() << " eV." << G4endl;
  }
  id = analysisManager->GetH1Id("WLS2 time");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " WLS2 emission time: mean = " << analysisManager->GetH1(id)->mean()
           << " ns; rms = " << analysisManager->GetH1(id)->rms() << " ns." << G4endl;
  }
  id = analysisManager->GetH1Id("x_backward");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " X momentum dir of backward-going photons: mean = "
           << analysisManager->GetH1(id)->mean() << "; rms = " << analysisManager->GetH1(id)->rms()
           << G4endl;
  }
  id = analysisManager->GetH1Id("y_backward");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Y momentum dir of backward-going photons: mean = "
           << analysisManager->GetH1(id)->mean() << "; rms = " << analysisManager->GetH1(id)->rms()
           << G4endl;
  }
  id = analysisManager->GetH1Id("z_backward");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Z momentum dir of backward-going photons: mean = "
           << analysisManager->GetH1(id)->mean() << "; rms = " << analysisManager->GetH1(id)->rms()
           << G4endl;
  }
  id = analysisManager->GetH1Id("x_forward");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " X momentum dir of forward-going photons: mean = "
           << analysisManager->GetH1(id)->mean() << "; rms = " << analysisManager->GetH1(id)->rms()
           << G4endl;
  }
  id = analysisManager->GetH1Id("y_forward");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Y momentum dir of forward-going photons: mean = "
           << analysisManager->GetH1(id)->mean() << "; rms = " << analysisManager->GetH1(id)->rms()
           << G4endl;
  }
  id = analysisManager->GetH1Id("z_forward");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Z momentum dir of forward-going photons: mean = "
           << analysisManager->GetH1(id)->mean() << "; rms = " << analysisManager->GetH1(id)->rms()
           << G4endl;
  }
  id = analysisManager->GetH1Id("x_fresnel");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " X momentum dir of Fresnel-refracted photons: mean = "
           << analysisManager->GetH1(id)->mean() << "; rms = " << analysisManager->GetH1(id)->rms()
           << G4endl;
  }
  id = analysisManager->GetH1Id("y_fresnel");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Y momentum dir of Fresnel-refracted photons: mean = "
           << analysisManager->GetH1(id)->mean() << "; rms = " << analysisManager->GetH1(id)->rms()
           << G4endl;
  }
  id = analysisManager->GetH1Id("z_fresnel");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Z momentum dir of Fresnel-refracted photons: mean = "
           << analysisManager->GetH1(id)->mean() << "; rms = " << analysisManager->GetH1(id)->rms()
           << G4endl;
  }
  id = analysisManager->GetH1Id("Transmitted");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Angle of transmitted photons: mean = " << analysisManager->GetH1(id)->mean()
           << "; rms = " << analysisManager->GetH1(id)->rms() << G4endl;
  }
  id = analysisManager->GetH1Id("Fresnel reflection");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Angle of Fresnel-reflected photons: mean = " << analysisManager->GetH1(id)->mean()
           << "; rms = " << analysisManager->GetH1(id)->rms() << G4endl;
  }
  id = analysisManager->GetH1Id("Total internal reflection");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Angle of total internal reflected photons: mean = "
           << analysisManager->GetH1(id)->mean() << "; rms = " << analysisManager->GetH1(id)->rms()
           << G4endl;
  }

  id = analysisManager->GetH1Id("Fresnel refraction");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Angle of Fresnel-refracted photons: mean = " << analysisManager->GetH1(id)->mean()
           << "; rms = " << analysisManager->GetH1(id)->rms() << G4endl;
  }

  id = analysisManager->GetH1Id("Absorption");
  if (analysisManager->GetH1Activation(id)) {
    G4cout << " Angle of absorbed photons: mean = " << analysisManager->GetH1(id)->mean()
           << "; rms = " << analysisManager->GetH1(id)->rms() << G4endl;
  }

  G4cout << G4endl;

  if (analysisManager->IsActive()) {
    analysisManager->Write();
    analysisManager->CloseFile();
  }

  const auto* detector = static_cast<const DetectorConstruction*>(
    G4RunManager::GetRunManager()->GetUserDetectorConstruction());
  if (detector && detector->IsRandomStateSavingEnabled()) {
    G4String basename = analysisManager->GetFileName();
    if (basename.size() >= 5 && basename.substr(basename.size() - 5) == ".root") {
      basename.erase(basename.size() - 5);
    }
    const G4String filename = basename + ".rng";
    std::ofstream randomState(filename);
    if (!randomState) {
      G4Exception("RunAction::EndOfRunAction", "DimpleRandom_002", FatalException,
                  ("Cannot open RNG end-state file: " + filename).c_str());
    }
    // Read the full engine/distribution state without drawing or resetting RNG.
    G4Random::saveFullState(randomState);
    randomState.close();
    if (!randomState) {
      G4Exception("RunAction::EndOfRunAction", "DimpleRandom_003", FatalException,
                  ("Cannot finish RNG end-state file: " + filename).c_str());
    }
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
